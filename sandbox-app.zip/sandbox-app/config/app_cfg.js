module.exports = {
  session_salt : 'giri'
};
